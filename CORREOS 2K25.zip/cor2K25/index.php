<?php 
header("location: corr/corr.php");
?>